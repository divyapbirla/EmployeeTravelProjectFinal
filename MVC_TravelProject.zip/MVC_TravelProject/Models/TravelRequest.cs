﻿using System;
using System.Collections.Generic;

namespace MVC_TravelProject.Models
{
    public partial class TravelRequest
    {
        public int RequestId { get; set; }
        public int? EmployeeId { get; set; }
        public DateTime? Date1 { get; set; }
        public string? FromDestination { get; set; }
        public string? ToDestination { get; set; }
        public string? Approve { get; set; }
        public string? BookingStatus { get; set; }
        public string? CurrentStatus { get; set; }

        public virtual Employee? Employee { get; set; }
    }
}
