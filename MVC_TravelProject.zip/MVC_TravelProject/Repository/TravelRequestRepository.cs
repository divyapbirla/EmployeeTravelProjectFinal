﻿using MVC_TravelProject.Models;

namespace MVC_TravelProject.Repository
{
    public class TravelRequestRepository:ITravelRequestRepository
    {
        private readonly travelProjectContext _context;

        public TravelRequestRepository(travelProjectContext context)
        {
            _context = context;
        }
        public IEnumerable<TravelRequest> GetRequests()
        {
            return _context.TravelRequests;
        }
        //Raise Request
        public void RaiseTravelRequest(TravelRequest treq)
        {
            if (treq != null)
            {
             
                treq.Approve = "pending";
                treq.BookingStatus = "pending";
                treq.CurrentStatus = "open";
                _context.TravelRequests.Add(treq);
                _context.SaveChanges();
            }
            

        }
        

        //Delete Request
        public void DeleteTravelRequest(int RequestId)
        {
            TravelRequest? treq = _context.TravelRequests.FirstOrDefault(x => x.RequestId == RequestId);
            if (treq != null)
            {
                _context.TravelRequests.Remove(treq);
                _context.SaveChanges();
            }
        }
        public TravelRequest GetTravelRequestById(int RequestId)
        {
           TravelRequest? treq = _context.TravelRequests.FirstOrDefault(x => x.RequestId == RequestId);
           return treq;
        }
        public void UpdateTravelRequest(TravelRequest treq, int RequestId)
        {
           TravelRequest? treq_old = _context.TravelRequests.FirstOrDefault(x => x.RequestId == RequestId);
           if (treq_old != null)
           {
               treq_old.FromDestination = treq.FromDestination;
               treq_old.ToDestination = treq.ToDestination;
               treq_old.Date1 = treq.Date1;

                _context.SaveChanges();

           }

        }

        //approve
        public void ApproveTravelRequest(int RequestId, string status)
        {
            TravelRequest tr = _context.TravelRequests.FirstOrDefault(x => x.RequestId == RequestId);

            if (tr != null)
            {
                tr.Approve = status;
                if (tr.Approve == "NotApproved")
                {
                    tr.CurrentStatus = "Close";
                    tr.BookingStatus = "-";
                }
                _context.SaveChanges();
            }
        }

        //book
        public void BookTravelRequest(int RequestId, string status)
        {

            TravelRequest tr = _context.TravelRequests.FirstOrDefault(x => x.RequestId == RequestId);

            if (tr != null)
            {

                tr.BookingStatus = status;
                tr.CurrentStatus = "Close";
                _context.SaveChanges(true);

            }

        }




    }
}
