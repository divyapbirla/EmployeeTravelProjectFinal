﻿using MVC_TravelProject.Models;

namespace MVC_TravelProject.Repository
{
    public interface ITravelRequestRepository
    {

        IEnumerable<TravelRequest> GetRequests();
        public void RaiseTravelRequest(TravelRequest treq);
        public void DeleteTravelRequest(int RequestId);
        public void UpdateTravelRequest(TravelRequest treq, int RequestId);
        public void ApproveTravelRequest(int RequestId, string Approve);
        public void BookTravelRequest(int RequestId, string BookingStatus);
        public TravelRequest GetTravelRequestById(int RequestId);

    }
}
