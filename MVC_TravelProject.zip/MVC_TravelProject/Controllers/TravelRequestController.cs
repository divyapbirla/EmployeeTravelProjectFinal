﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using MVC_TravelProject.Models;
using MVC_TravelProject.Repository;

namespace MVC_TravelProject.Controllers
{
    public class TravelRequestController : Controller
    {
        private readonly IEmployeeRepository Ier;
        private readonly ITravelRequestRepository Itr;
        public TravelRequestController(IEmployeeRepository er, ITravelRequestRepository tr)
        {
            Ier = er;
           Itr = tr;
        }
        public IActionResult Index()
        {
            IEnumerable<TravelRequest> req = Itr.GetRequests();
            return View(req);
        }

        

        //raise neww
        public IActionResult RaiseTravelRequest()
        {
            var employees = Ier.GetEmployees()
                .Select(e => new
                {
                    EmployeeId = e.EmployeeId,
                    FullName = $"{e.FirstName} {e.LastName}"
                });

            ViewBag.Employees = new SelectList(employees, "EmployeeId", "FullName");
            return View();
        }

        [HttpPost]

        public IActionResult RaiseTravelRequest(TravelRequest treq)
        {
            if (ModelState.IsValid)
            {
                Itr.RaiseTravelRequest(treq);
            }
            return RedirectToAction("Index");
        }
        //raise ends

        //Delete Request
        public IActionResult DeleteTravelRequest(int RequestId)
        {

            Itr.DeleteTravelRequest(RequestId);
            return RedirectToAction("Index");
        }

        
        //update new
        public IActionResult UpdateTravelRequest(int RequestId)
        {
            TravelRequest? treq = Itr.GetTravelRequestById(RequestId);
            var employees = Ier.GetEmployees()
                   .Select(e => new
                   {
                       EmployeeId = e.EmployeeId,
                       FullName = $"{e.FirstName} {e.LastName}"
                   });

            ViewBag.Employees = new SelectList(employees, "EmployeeId", "FullName");
            if (treq != null)
            {
                return View(treq);
            }
            return RedirectToAction("Index");
        }
        [HttpPost]
        public IActionResult UpdateTravelRequest(TravelRequest treq, int RequestId)
        {
            if (ModelState.IsValid)
            {

                Itr.UpdateTravelRequest(treq, RequestId);

            }
            return RedirectToAction("Index");
        }
        //update new end

        //approvee

        public IActionResult ApproveTravelRequest(int id)
        {
            TravelRequest tr = Itr.GetTravelRequestById(id);
            return View(tr);
        }

        [HttpPost]
        public IActionResult ApproveTravelRequest(int RequestId, string Approve)
        {
            if (ModelState.IsValid)
            {
                Itr.ApproveTravelRequest(RequestId, Approve);
            }
            return RedirectToAction("Index");
        }

        // Book

        public IActionResult BookTravelRequest(int id)
        {
            TravelRequest tr = Itr.GetTravelRequestById(id);
            return View(tr);
        }

        [HttpPost]
        public IActionResult BookTravelRequest(int RequestId, string BookingStatus)
        {
            if (ModelState.IsValid)
            {
                Itr.BookTravelRequest(RequestId, BookingStatus);
            }
            return RedirectToAction("Index");
        }



    }
}
